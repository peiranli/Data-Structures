package hw8;


public class LineCounter {
	
	public static void printToConsole(String filename, String compareFileName, int percentage) {
		if(!filename.isEmpty())
			System.out.println("\n"+filename+":");
		
		if(!compareFileName.isEmpty())
				System.out.println(percentage+"% of lines are also in "+compareFileName);
	}
	
	public static void main(String[] args) {
		
		if(args.length<1) {
			System.err.println("Invalid number of arguments passed");
			return;
		}
		
		int numArgs = args.length;
		HashTable[] tableList = new HashTable[numArgs];
		
		//Preprocessing: Read every file and create a HashTable
		
		for(int i=0; i<numArgs; i++) {
			
			//TODO
		}
		
		//Find similarities across files
		
		for(int i=0; i<numArgs; i++) {
			
			//TODO
			
		}
	}

}
